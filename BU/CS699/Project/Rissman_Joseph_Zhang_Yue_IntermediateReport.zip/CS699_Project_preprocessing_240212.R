########################################################################
######                                                          ########
######      Part of code adopted from class code example        ########
######                                                          ########
########################################################################


######################## required libraries ############################

library(dplyr)
library(tidyr)
library(caret)

######################## helper functions ##############################

sort_null_counts <- function(data) {
  # Output null count in each column
  null_counts <- colSums(is.na(data))
  
  # Sort null counts
  sorted_null_counts <- sort(null_counts, decreasing = TRUE)
  
  # Print sorted null counts
  print(sorted_null_counts)
}

drop_columns_with_nulls <- function(data, threshold = 0.75) {
  # Calculate the threshold for null values
  null_threshold <- nrow(data) * threshold
  
  # Find columns with null values exceeding the threshold
  cols_to_drop <- colSums(is.na(data)) > null_threshold
  
  # Drop columns exceeding the threshold
  data <- data[, !cols_to_drop]
  
  return(data)
}

###################### Load data file ##################################

df <- read.csv('./Project/project_dataset_5K.csv')

####### Remove variables from sections without health data #############

vars_to_remove <- c("X_STATE","FMONTH","IDATE","IMONTH","IDAY","IYEAR",
                    "DISPCODE","SEQNO","X_PSU","CTELENM1","PVTRESD1",
                    "COLGHOUS","STATERE1","CELPHONE","LADULT1","COLGSEX",
                    "NUMADULT","LANDSEX","NUMMEN","NUMWOMEN","RESPSLCT",
                    "SAFETIME","CTELNUM1","CELLFON5","CADULT1","CELLSEX",
                    "PVTRESD3","CCLGHOUS","CSTATE1", "LANDLINE","HHADULT",
                    "QSTVER","QSTLANG")
df <- select(df,-all_of(vars_to_remove))

######### Remove variables with more than 75% of NULL values ###########

df <- drop_columns_with_nulls(df, 0.75)

############## Remove near zero variants point #########################

df <- df[,-nearZeroVar(df)]

############## Remove highly correlated variables ######################

## cor gives warning message from variables where standard deviation is zero
corr_matrix <- cor(select_if(df,is.numeric),use = "pairwise.complete.obs")
## replace NA correlation with 1 where one variable completely depends on another
corr_matrix <- corr_matrix %>% replace(is.na(.),1)
highCorr <- findCorrelation(corr_matrix, cutoff = 0.7, exact = TRUE)
df <- df[,-highCorr]

########## Replace missing values with class median ###################

## split data based on classification
df_no <- filter(df,Class == "N")
df_yes <- filter(df,Class == "Y")
## replace NA with median
df_no <- df_no %>% mutate(across(where(is.numeric), ~replace_na(., median(., na.rm=TRUE))))
df_yes <- df_yes %>% mutate(across(where(is.numeric), ~replace_na(., median(., na.rm=TRUE))))
## merge back to full data set
df <- rbind(df_no,df_yes)

########## Output preprocessed data file ###############################

write.csv(df, file = "./Project/preprocessed_data.csv")
