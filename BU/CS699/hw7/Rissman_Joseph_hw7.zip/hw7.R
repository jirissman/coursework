library(arules)
library(arulesViz)


df <-read.transactions('hw7/groceries3000.csv', sep = ",")
summary(df)
colnames(df)
as(df, "matrix")
image(df)
inspect(df)
itemFrequency(df)

# mine frequent itemsets
L <- apriori(df, support = 0.04, target = "frequent itemsets")
summary(L)
inspect(L)
inspect(sort(L, by = "support"))
inspect(L[size(L)==1])
inspect(L[size(L)==2])
inspect(L[size(L)==3])
inspect(L[size(L)==4])

# mine rules
rules <- apriori(df, support = 0.01, confidence = 0.25, target = "rules")
summary(rules)
inspect(rules)
inspect(sort(rules, by = "confidence")[1:5])
inspect(sort(rules, by = "support")[1:5])
inspect(subset(rules, items %in% "yogurt"))
