library(rpart) # needed for decision tree
library(caret) # needed for confusion matrix
# read csv into df
train <- read.csv("./hw5/hw5_p4_train.csv")
test <- read.csv("./hw5/hw5_p4_test.csv")
# convert class to factor
train$y <- factor(train$y)
test$y <- factor(test$y)
# construct decision tree with rpart
tree <- rpart(y ~ ., train)
# predict with test dataset
pred <- predict(tree,newdata = test,type="class")
# produce performance measures
performance <- confusionMatrix(data=pred, reference = test$y)
# save results to csv
capture.output(performance,file="./hw5/hw5_p4_1_confusion_matrix.csv")

# create undersampled and oversampled training dataset using caret
undersampled <- downSample(train,train$y,yname="y")
oversampled <- upSample(train,train$y,yname="y")
# save new datasets to csv
write.csv(undersampled,file="./hw5/hw5_p4_train_undersampled.csv")
write.csv(oversampled,file="./hw5/hw5_p4_train_oversampled.csv")
# construct decision trees with rpart
under.tree <- rpart(y ~ ., undersampled)
over.tree <- rpart(y ~ ., oversampled)
# predict with test dataset
under.pred <- predict(under.tree,newdata = test,type="class")
over.pred <- predict(over.tree,newdata = test,type="class")
# produce performance measures
under.performance <- confusionMatrix(data=under.pred, reference = test$y)
over.performance <- confusionMatrix(data=over.pred, reference = test$y)
# save results to csv
capture.output(under.performance,file="./hw5/hw5_p4_2_confusion_matrix.csv")
capture.output(over.performance,file="./hw5/hw5_p4_3_confusion_matrix.csv")
