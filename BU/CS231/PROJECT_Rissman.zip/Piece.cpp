// Chess piece implementation file
// Edit History:
// 11/24/2022 Created implementation file

#include "Piece.h"

Piece::Piece(Color c, Type t, const Square& p)
{
	setColor(c);
	setType(t);
	setPos(p);
}

void Piece::setColor(Color c)
{
	color = c;
}

Piece::Color Piece::getColor() const
{
	return color;
}

string Piece::printColor() const
{
	switch (color)
	{
	case Piece::white:
		return "white";
	case Piece::black:
		return "black";
	default:
		return "null";
	};
}

void Piece::setType(Type t)
{
	type = t;
}

Piece::Type Piece::getType() const
{
	return type;
}

string Piece::printType() const
{
	switch (type)
	{
	case Piece::king:
		return "king";
	case Piece::queen:
		return "queen";
	case Piece::rook:
		return "rook";
	case Piece::knight:
		return "knight";
	case Piece::bishop:
		return "bishop";
	case Piece::pawn:
		return "pawn";
	default:
		return "null";
	}
}

void Piece::setPos(const Square& pos)
{
	position = pos;
}

Square Piece::getPos() const
{
	return position;
}

void Piece::setLegalMoves(const vector<Move>& moves)
{
	legalMoves = moves;
}

vector<Move> Piece::getPseudoMoves() const
{
	return possibleMoves;
}

vector<Move> Piece::getLegalMoves() const
{
	return legalMoves;
}

void Piece::generateMoves(const list<Piece>& others)
{
	switch (type)
	{
	case king: possibleMoves = kingMoves(getColor(), getPos(), others); break;
	case queen: possibleMoves = queenMoves(getColor(), getPos(), others); break;
	case rook: possibleMoves = rookMoves(getColor(), getPos(), others); break;
	case knight: possibleMoves = knightMoves(getColor(), getPos(), others); break;
	case bishop: possibleMoves = bishopMoves(getColor(), getPos(), others); break;
	case pawn: possibleMoves = pawnMoves(getColor(), getPos(), others); break;
	default: cout << "something went horribly wrong while generating moves"; break;
	};
}

vector<Move> Piece::createMoves(const Square& start, const vector<Square>& targets)
{
	vector<Move> output;
	transform(targets.cbegin(), targets.cend(), back_inserter(output),
		[start](Square target) {return Move(start, target); });
	return output;
}

vector<Move> Piece::kingMoves(Color color, const Square& square, const list<Piece>& others)
{
	vector<Square> targets;
	for (size_t i = 0; i < 8; i++)	// add target square for each direction king can move
	{
		Square kingPosition = square;
		if (!kingPosition.shift((Square::Direction)i))
		{
			continue;
		}
		if (none_of(others.cbegin(), others.cend(), [color, kingPosition](Piece p) {return kingPosition == p.getPos() && color == p.getColor(); }))
		{
			targets.push_back(kingPosition);
		}
	}
	return createMoves(square, targets);
}

vector<Move> Piece::queenMoves(Color color, const Square& square, const list<Piece>& others)
{
	vector<Square> targets;
	for (int d = 0; d < 8; d++) // iterate over each direction queen can move
	{
		for (int l = 1; l < 8; l++) // iterate over each distance queen can move
		{
			Square queenPosition = square;
			if (!queenPosition.shift((Square::Direction)d, l))
			{
				break; // skips to next direction if move is impossible
			}
			if (any_of(others.cbegin(), others.cend(), [color, queenPosition](Piece p)
				{return queenPosition == p.getPos() && color == p.getColor(); }))
			{
				break; // skips to next direction once any friendly piece is encountered
			}
			else if (any_of(others.cbegin(), others.cend(), [color, queenPosition](Piece p)
				{return queenPosition == p.getPos() && color != p.getColor(); }))
			{
				targets.push_back(queenPosition);
				break; // records valid move then skips to next direction once any enemy piece is encountered
			}
			targets.push_back(queenPosition);
		}
	}
	return createMoves(square, targets);
}

vector<Move> Piece::rookMoves(Color color, const Square& square, const list<Piece>& others)
{
	vector<Square> targets;
	for (int d = 0; d < 4; d++) // iterate over each direction rook can move
	{
		for (int l = 1; l < 8; l++) // iterate over each distance rook can move
		{
			Square rookPosition = square;
			if (!rookPosition.shift((Square::Direction)(d * 2), l))
			{
				break; // skips to next direction if move is invalid
			}
			if (any_of(others.cbegin(), others.cend(), [color, rookPosition](Piece p)
				{return rookPosition == p.getPos() && color == p.getColor(); }))
			{
				break; // skips to next direction once any friendly piece is encountered
			}
			else if (any_of(others.cbegin(), others.cend(), [color, rookPosition](Piece p)
				{return rookPosition == p.getPos() && color != p.getColor(); }))
			{
				targets.push_back(rookPosition);
				break; // records valid move then skips to next direction once any enemy piece is encountered
			}
			targets.push_back(rookPosition);
		}
	}
	return createMoves(square, targets);
}

vector<Move> Piece::knightMoves(Color color, const Square& square, const list<Piece>& others)
{
	vector<Square> targets;
	for (int d = 0; d < 4; d++) // iterate over each direction knight can move
	{
		for (int i = 0; i < 2; i++)
		{
			// shift 2 in cardinal direction then each direction adjacent
			Square knightPosition = square;
			if (!knightPosition.shift((Square::Direction)(d * 2), 2))
			{
				break; // skips to next direction if cardinal direction move is invalid
			}
			if (!knightPosition.shift((Square::Direction)(((d * 2) + 6 + (i * 4)) % 8)))
			{
				continue; // skips to next direction if adjacent direction move is invalid
			}
			if (none_of(others.cbegin(), others.cend(), [color, knightPosition](Piece p)
				{return knightPosition == p.getPos() && color == p.getColor(); }))
			{
				targets.push_back(knightPosition);
			}
		}
	}
	return createMoves(square, targets);
}

vector<Move> Piece::bishopMoves(Color color, const Square& square, const list<Piece>& others)
{
	vector<Square> targets;
	for (int d = 0; d < 4; d++) // iterate over each direction bishop can move
	{
		for (int l = 1; l < 8; l++) // iterate over each distance bishop can move
		{
			Square bishopPosition = square;
			if (!bishopPosition.shift((Square::Direction)(d * 2 + 1), l))
			{
				break; // skips to next direction if move is invalid
			}
			if (any_of(others.cbegin(), others.cend(), [color, bishopPosition](Piece p)
				{return bishopPosition == p.getPos() && color == p.getColor(); }))
			{
				break; // skips to next direction once any friendly piece is encountered
			}
			else if (any_of(others.cbegin(), others.cend(), [color, bishopPosition](Piece p)
				{return bishopPosition == p.getPos() && color != p.getColor(); }))
			{
				targets.push_back(bishopPosition);
				break; // records valid move then skips to next direction once any enemy piece is encountered
			}
			targets.push_back(bishopPosition);
		}
	}
	return createMoves(square, targets);
}

vector<Move> Piece::pawnMoves(Color color, const Square& square, const list<Piece>& others)
{
	vector<Square> targets;
	Square pawnPosition = square;
	if (pawnPosition.shift(color == white ? square.N : square.S))
	{
		// check square in front of pawn for any piece
		if (none_of(others.cbegin(), others.cend(), [pawnPosition](Piece p)
			{return pawnPosition == p.getPos(); }))
		{
			targets.push_back(pawnPosition);
			// check if pawn is on starting square
			if (color == white && square.getRank() == 2 || color == black && square.getRank() == 7)
			{
				// check square 2 in front for any piece
				pawnPosition.shift(color == white ? square.N : square.S);
				if (none_of(others.cbegin(), others.cend(), [pawnPosition](Piece p)
					{return pawnPosition == p.getPos(); }))
				{
					targets.push_back(pawnPosition);
				}
			}
		}
	}
	pawnPosition = square; 	// check square diagonally west in front of pawn for enemy piece
	if (pawnPosition.shift(color == white ? square.NW : square.SW))
	{
		if (any_of(others.cbegin(), others.cend(), [color, pawnPosition](Piece p)
			{return pawnPosition == p.getPos() && color != p.getColor(); }))
		{
			targets.push_back(pawnPosition);
		}
	}
	pawnPosition = square; // check square diagonally east in front of pawn for enemy piece
	if (pawnPosition.shift(color == white ? square.NE : square.SE))
	{
		if (any_of(others.cbegin(), others.cend(), [color, pawnPosition](Piece p)
			{return pawnPosition == p.getPos() && color != p.getColor(); }))
		{
			targets.push_back(pawnPosition);
		}
	}
	return createMoves(square, targets);
}

bool Piece::operator==(const Piece& other) const
{
	return getColor() == other.getColor() && getType() == other.getType() && getPos() == other.getPos();
}

bool Piece::operator!=(const Piece& other) const
{
	return getColor() != other.getColor() || getType() != other.getType() || getPos() != other.getPos();
}

void Piece::displayInfo() const
{
	cout << "\nThe " << printColor()
		<< " " << printType()
		<< " is on " << (string)getPos();
	cout << "\nThe pseudolegal moves are: ";
	for (auto& move : getPseudoMoves())
	{
		cout << move.toString() << " ";
	};
	cout << "\n      The legal moves are: ";
	for (auto& move : getLegalMoves())
	{
		cout << move.toString() << " ";
	};
}