#include "Square.h"
#include <stdexcept>

Square::Square(const string& str)
{
	setPosition(str);
}

Square::Square(char file, char rank)
{
	setPosition(file, rank);
}

Square::Square(int pos)
{
	setPosition(pos);
}

void Square::setPosition(const string& str)
{
	setPosition(str_to_int(str));
}

void Square::setPosition(char file, char rank)
{
	setPosition(char_to_int(file, rank));
}

void Square::setPosition(int pos)
{
	if (pos < 0 || pos > 63)
	{
		throw invalid_argument("Unable to create square");
	}
	position = pos;
}

int Square::getPosition() const
{
	return position;
}

int Square::getFile() const
{
	return position % 8 + 1;
}

int Square::getRank() const
{
	return position / 8 + 1;
}

bool Square::shift(Direction dir, int dist)
{
	if (dist < 1 || dist > 7)
	{
		return false;
	}

	if (dir == NW)
	{
		if (getFile() - dist < 1 || getRank() + dist > 8)
		{
			return false;
		}
		setPosition(getPosition() + dist * 7);
	}
	else if (dir == N)
	{
		if (dist + getRank() > 8)
		{
			return false;
		}
		setPosition(getPosition() + dist * 8);
	}
	else if (dir == NE)
	{
		if (dist + getFile() > 8 || dist + getRank() > 8)
		{
			return false;
		}
		setPosition(getPosition() + dist * 9);
	}
	else if (dir == E)
	{
		if (dist + getFile() > 8)
		{
			return false;
		}
		setPosition(getPosition() + dist);
	}
	else if (dir == SE)
	{
		if (dist + getFile() > 8 || getRank() - dist < 1)
		{
			return false;
		}
		setPosition(getPosition() - dist * 7);
	}
	else if (dir == S)
	{
		if (getRank() - dist < 1)
		{
			return false;
		}
		setPosition(getPosition() - dist * 8);
	}
	else if (dir == SW)
	{
		if (getFile() - dist < 1 || getRank() - dist < 1)
		{
			return false;
		}
		setPosition(getPosition() - dist * 9);
	}
	else if (dir == W)
	{
		if (getFile() - dist < 1)
		{
			return false;
		}
		setPosition(getPosition() - dist);
	}
	else
	{
		return false;
	}
	return true;
}

Square::operator string() const
{
	return Square::int_to_str(getPosition());
}

Square::operator int() const
{
	return getPosition();
}

//bool Square::operator==(const Square& other) const
//{
//	return (this->getPosition() == other.getPosition());
//}

string Square::int_to_str(int pos)
{
	if (pos < 0 || pos > 63)
	{
		throw invalid_argument("Invalid int_to_str conversion");
	}
	else
	{
		char file = (pos % 8) + 97;
		char rank = (pos / 8) + 49;
		string output{ file, rank };
		return output;
	}
}

int Square::char_to_int(char file, char rank)
{
	if (file > 'h' || file < 'a')
	{
		throw invalid_argument("\nInvalid char_to_int conversion");
	}
	if (rank > '8' || rank < '1')
	{
		throw invalid_argument("\nInvalid char_to_int conversion");
	}
	else
	{
		return (file - 97) + ((rank - 49) * 8);
	}
}

int Square::str_to_int(const string& str)
{
	if (str.length() != 2)
	{
		throw invalid_argument("\nInvalid string " + str);
	}
	if (str[0] > 'h' || str[0] < 'a')
	{
		throw invalid_argument("\nInvalid square " + str);
	}
	if (str[1] > '8' || str[1] < '1')
	{
		throw invalid_argument("\nInvalid square " + str);
	}
	else
	{
		int file = (str[0] - 97);
		int rank = (str[1] - 49) * 8;
		return rank + file;
	}
}
