#pragma once
#include <string>
using namespace std;

class Square
{
public:
	// enumerations
	enum Direction { N, NE, E, SE, S, SW, W, NW };

	// constructors
	Square(const string&);
	Square(char, char);
	Square(int = 0);

	// setters and getters
	void setPosition(const string&);
	void setPosition(char, char);
	void setPosition(int);
	int getPosition() const;
	int getFile() const;
	int getRank() const;

	// returns true if shift is successful and false if unsuccessful
	bool shift(Direction dir, int dist = 1);

	// overloaded operators
	operator string() const;
	operator int() const;
	//bool operator== (const Square&) const;

	static string int_to_str(int);
	static int char_to_int(char, char);
	static int str_to_int(const string&);

private:
	int position;
};

