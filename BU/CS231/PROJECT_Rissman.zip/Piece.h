// Chess piece specification file
// Edit History:
// 11/24/2022 Created specification file
// 11/24/2022 Added setters, getters, constructors

#pragma once
#include <string>
#include <stdexcept>
#include <vector>
#include <list>
#include <iostream>
#include <algorithm>
#include "Move.h"
using namespace std;

class Piece
{
public:
	// enumerations
	enum Color { white, black };
	enum Type { king, queen, rook, knight, bishop, pawn };

	// constructors
	Piece(Color color, Type type, const Square& pos);

	// setters and getters
	void setColor(Color c);
	Color getColor() const;
	string printColor() const;
	void setType(Type t);
	Type getType() const;
	string printType() const;
	void setPos(const Square& pos);
	Square getPos() const;
	void setLegalMoves(const vector<Move>&);
	vector<Move> getPseudoMoves() const;
	vector<Move> getLegalMoves() const;

	// functions to find all pseudolegal moves
	void generateMoves(const list<Piece>& others); // populates possibleMoves. must provide other pieces
	static vector<Move> createMoves(const Square& start, const vector<Square>& targets); // helper function to turn squares into moves
	static vector<Move> kingMoves(Color color, const Square& pos, const list<Piece>& others); // find all possible moves for a king
	static vector<Move> queenMoves(Color color, const Square& pos, const list<Piece>& others); // find all possible moves for a queen
	static vector<Move> rookMoves(Color color, const Square& pos, const list<Piece>& others); // find all possible moves for a rook
	static vector<Move> knightMoves(Color color, const Square& pos, const list<Piece>& others); // find all possible moves for a knight
	static vector<Move> bishopMoves(Color color, const Square& pos, const list<Piece>& others); // find all possible moves for a bishop
	static vector<Move> pawnMoves(Color color, const Square& pos, const list<Piece>& others); // find all possible moves for a pawn

	// operator overload
	bool operator== (const Piece&) const;
	bool operator!= (const Piece&) const;

	// returns information about the piece
	void displayInfo() const;

private:
	Color color;							// Piece color: white or black
	Type type;								// Piece type: K, Q, R, B, N, or P
	Square position;						// Coordinates of piece
	vector <Move> possibleMoves;			// list of pseudolegal moves
	vector <Move> legalMoves;				// list of legal moves

};

