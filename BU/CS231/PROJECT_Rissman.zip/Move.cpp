#include "Move.h"

Move::Move(const string& str) // full move notation
{
	
	if (str.length() != 4)
	{
		throw invalid_argument("Unable to create move");
	}
	setStart(str.substr(0, 2));
	setEnd(str.substr(2, 2));
}

Move::Move(char startfile, char startrank, char endfile, char endrank) // input individual columns and rows 
{
	setStart(Square::char_to_int(startfile, startrank));
	setEnd(Square::char_to_int(endfile, endrank));
}

Move::Move(int start, int end)
{
	setStart(start);
	setEnd(end);
}

Move::Move(Square s, Square e)
{
	start = s;
	end = e;
}

void Move::setStart(const Square& s)
{
	start = s;
}

void Move::setStart(int pos)
{
	Square s(pos);
	start = s;
}

Square Move::getStart() const
{
	return start;
}

void Move::setEnd(const Square& e)
{
	end = e;
}

void Move::setEnd(int pos)
{
	Square e(pos);
	end = e;
}

Square Move::getEnd() const
{
	return end;
}

bool Move::operator==(const Move& other) const
{
	return toString() == other.toString();
}

bool Move::operator!=(const Move& other) const
{
	return toString() != other.toString();
}

bool Move::validateNotation(const string& str)
{
	if (str.length() != 4)
	{
		return false;
		//throw invalid_argument("Must use c1r1 notation");
	}
	if (str[0] > 'h' || str[0] < 'a')
	{
		return false;
		//throw invalid_argument("Incorrect notation");
	}
	if (str[1] > '8' || str[1] < '1')
	{
		return false;
		//throw invalid_argument("Incorrect notation");
	}
	if (str[2] > 'h' || str[2] < 'a')
	{
		return false;
		//throw invalid_argument("Incorrect notation");
	}
	if (str[3] > '8' || str[3] < '1')
	{
		return false;
		//throw invalid_argument("Incorrect notation");
	}
		return true;
}

string Move::toString() const
{
	return string(Square::int_to_str(start.getPosition()) + Square::int_to_str(end.getPosition()));
}
