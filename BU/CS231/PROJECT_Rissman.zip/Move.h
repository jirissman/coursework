#pragma once
#include <string>
#include <stdexcept>
#include "Square.h"
using namespace std;

class Move
{
public:
	// constructors
	Move(const string&);
	Move(char, char, char, char);
	Move(int, int);
	Move(Square, Square);

	// setters and getters
	void setStart(const Square&);
	void setStart(int);
	Square getStart() const;
	void setEnd(const Square&);
	void setEnd(int);
	Square getEnd() const;

	// overload operators
	bool operator==(const Move&) const;
	bool operator!=(const Move&) const;

	// makes sure move notation is correct
	static bool validateNotation(const string&);

	string toString() const;
private:
	Square start;	// Starting position
	Square end;		// Ending position
};

