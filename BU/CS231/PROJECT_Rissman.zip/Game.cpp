#include "Game.h"

Game::Game(const list<Piece>& pieces, const vector<Move>& history, STATUS status, unsigned int ply)
{
	setPieces(pieces);
	setHistory(history);
	setStatus(status);
	setPly(ply);
	updateMoves();
}

void Game::setPieces(const list<Piece>& pieces)
{
	vector<Square> positions;
	transform(pieces.cbegin(), pieces.cend(), back_inserter(positions), [](Piece p) {return p.getPos(); });
	sort(positions.begin(), positions.end());
	auto PosIt = unique(positions.begin(), positions.end());

	if (pieces.size() > 32)
	{
		throw invalid_argument("Maximum number of pieces is 32");
	}
	else if (PosIt != positions.end())
	{
		throw logic_error("Only one piece can occupy each square");
	}
	else
	{
		Pieces = pieces;
	}
}

list<Piece> Game::getAllPieces() const
{
	return Pieces;
}

list<Piece> Game::getWhitePieces() const
{
	list<Piece> white{};
	copy_if(Pieces.cbegin(), Pieces.cend(), back_inserter(white), [](Piece p) {return p.getColor() == Piece::white; });
	return white;
}

list<Piece> Game::getBlackPieces() const
{
	list<Piece> black{};
	copy_if(Pieces.cbegin(), Pieces.cend(), back_inserter(black), [](Piece p) {return p.getColor() == Piece::black; });
	return black;
}

vector<Square> Game::getPositions() const
{
	vector<Square> positions;
	for (auto& piece : Pieces)
	{
		positions.push_back(piece.getPos());
	}
	return positions;
}

void Game::setHistory(const vector<Move>& history)
{
	Game::history = history;
}

vector<Move> Game::getHistory() const
{
	return history;
}

void Game::setStatus(STATUS status)
{
	Game::status = status;
}

Game::STATUS Game::getStatus() const
{
	return Game::status;
}

void Game::setPly(unsigned int ply)
{
	Game::ply = ply;
}

unsigned int Game::getPly() const
{
	return Game::ply;
}

void Game::setLegalMoves(Piece& piece)
{
	vector<Move> legalMoves;
	for (auto& move : piece.getPseudoMoves())
	{
		if (!makeTestMove(move).inCheck(piece.getColor()))
		{
			legalMoves.push_back(move);
		}
	}
	piece.setLegalMoves(legalMoves);
}

bool Game::inCheck(Piece::Color player) const
{
	// find enemy information
	const Piece::Color enemyColor = player == Piece::white ? Piece::black : Piece::white;
	const vector<Move> enemyMoves = getPseudoMoves(enemyColor);
	vector<Square> enemyTargets;
	transform(enemyMoves.cbegin(), enemyMoves.cend(), back_inserter(enemyTargets),
		[](Move enemyMove) {return enemyMove.getEnd(); });
	// get friendly king position
	const Square kingPosition =
		find_if(Pieces.cbegin(), Pieces.cend(),
			[player](Piece p) {return p.getType() == Piece::king && p.getColor() == player; })->getPos();
	// check if any enemy piece can capture the king
	return any_of(enemyTargets.cbegin(), enemyTargets.cend(), [kingPosition](Square target) {return target == kingPosition; });
}


void Game::addPiece(const Piece& toAdd)
{
	if (none_of(Pieces.cbegin(), Pieces.cend(), [toAdd](Piece p) {return toAdd.getPos() == p.getPos(); }))
	{
		Pieces.push_back(toAdd);
	}
}

void Game::removePiece(const Piece& toRemove)
{
	remove(Pieces.begin(), Pieces.end(), toRemove);
}

void Game::promotePiece(Piece& piece)
{
	// ask player what to promote to
	cout << "Enter piece to promote to (Q/R/N/B): ";
	char input;
	Piece::Type update = Piece::pawn;
	while (cin >> input)
	{
		switch (input)
		{
		case 'Q': update = Piece::queen; break;
		case 'R': update = Piece::rook; break;
		case 'N': update = Piece::knight; break;
		case 'B': update = Piece::bishop; break;
		default:
			break;
		}
		if (update != Piece::pawn)
		{
			break;
		}
	}
	piece.setType(update);
}

vector<Move> Game::getPseudoMoves(const Piece::Color player) const
{
	vector<Move> playerMoves;
	for (auto& piece : Pieces)
	{
		if (piece.getColor() == player)
		{
			const vector<Move> pieceMoves = piece.getPseudoMoves();
			playerMoves.insert(playerMoves.cend(), pieceMoves.cbegin(), pieceMoves.cend());
		}
	}
	return playerMoves;
}

vector<Move> Game::getLegalMoves(const Piece::Color player) const
{
	vector<Move> playerMoves;
	for (auto& piece : Pieces)
	{
		if (piece.getColor() == player)
		{
			const vector<Move> pieceMoves = piece.getLegalMoves();
			playerMoves.insert(playerMoves.cend(), pieceMoves.cbegin(), pieceMoves.cend());
		}
	}
	return playerMoves;
}

void Game::updateMoves()
{
	for (auto& piece : Pieces)
	{
		piece.generateMoves(Pieces);
	}
	for (auto& piece : Pieces)
	{
		setLegalMoves(piece);
	}
}

void Game::updateStatus()
{
	// check if checkmate or stalemate
	const Piece::Color activePlayer = ((Piece::Color)(getPly() % 2));
	if (getLegalMoves(activePlayer).empty())
	{
		// if no legal moves remain either the player is in check and checkmated or not in check and stalemated
		inCheck(activePlayer) ? setStatus(Checkmate) : setStatus(Draw);
		return;
	}
	// check if insufficient material for checkmate
	int whiteCount = 0;
	int blackCount = 0;
	for (auto& piece : getWhitePieces())
	{
		if (piece.getType() == Piece::bishop || piece.getType() == Piece::knight) { whiteCount++; }
	}
	for (auto& piece : getBlackPieces())
	{
		if (piece.getType() == Piece::bishop || piece.getType() == Piece::knight) { blackCount++; }
	}
	if (whiteCount <= 1 && blackCount <= 1 && none_of(Pieces.cbegin(), Pieces.cend(),
		[](Piece p) {return p.getType() == Piece::queen || p.getType() == Piece::rook || p.getType() == Piece::pawn; }))
	{
		setStatus(Draw);
		return;
	}
	setStatus((STATUS)(getPly() % 2));
}

void Game::makeMove(const Move& move)
{
	// validate move is legal
	switch (validateMove(move))
	{
	case 2: throw invalid_argument("\nInvalid move"); break;
	case 1: throw invalid_argument("\nIllegal move"); break;
	case 0: break;// move is valid, continue with code
	default: break;
	}

	// remove any pieces at end square
	auto removeIt = remove_if(Pieces.begin(), Pieces.end(),
		[move](Piece p) {return p.getPos() == move.getEnd(); });
	Pieces.erase(removeIt,Pieces.cend());

	// find the piece at start and update its position to end
	auto pieceIt = find_if(Pieces.begin(), Pieces.end(),
		[move](Piece p) {return p.getPos() == move.getStart(); });
	pieceIt->setPos(move.getEnd());

	// check if pawn is promoting
	if (pieceIt->getType() == Piece::pawn && (pieceIt->getPos().getRank() == 8 || pieceIt->getPos().getRank() == 1))
	{
		promotePiece(*pieceIt);
	}

	// update possible moves
	updateMoves();

	// add move to history
	Game::history.push_back(move);

	// increment ply
	Game::ply++;

	// update status
	updateStatus();
	return;
}

Game Game::makeTestMove(const Move& move) const
{
	Game output = *this;

	// remove any pieces at end square
	remove_if(output.Pieces.begin(), output.Pieces.end(),
		[move](Piece p) {return p.getPos() == move.getEnd(); });

	// find the piece at start and update its position to end
	find_if(output.Pieces.begin(), output.Pieces.end(),
		[move](Piece p) {return p.getPos() == move.getStart(); })->setPos(move.getEnd());

	for (auto& piece : output.Pieces)
	{
		piece.generateMoves(output.Pieces);
	}
	return output;
}

int Game::validateMove(const Move& toValidate)
{
	const Piece::Color activePlayer = (getStatus() == WhiteToMove ? Piece::white : Piece::black);
	const vector<Move> pseudoMoves = getPseudoMoves(activePlayer);
	const vector<Move> legalMoves = getLegalMoves(activePlayer);
	if (any_of(legalMoves.cbegin(), legalMoves.cend(), [toValidate](Move legal) {return legal == toValidate; }))
	{
		return 0; // move is valid and legal
	}
	if (any_of(pseudoMoves.cbegin(), pseudoMoves.cend(), [toValidate](Move pseudo) {return pseudo == toValidate; }))
	{
		return 1; // move is valid but not legal
	}
	return 2; // move is invalid
}

void Game::printBoard() const
{
	printFileLabels();
	printTopLine();
	for (size_t i = 8; i > 0; --i)
	{
		printLine(i - 1);
	}
	cout << endl;
	printFileLabels();
	cout << "Move History" << endl;
	for (size_t i = 0; i < getHistory().size(); i++)
	{
		if ((i % 2) == 0)
		{
			cout << i + 1 << ". " << getHistory().at(i).toString();
		}
		else
		{
			cout << " " << i + 1 << ". " << getHistory().at(i).toString() << endl;
		}
	}
	if ((getPly() % 2) != 0)
	{
		cout << endl;
	}
	cout << (Game::status == WhiteToMove ? "White" : "Black") << " to move";
}

void Game::printLine(int line) const
{
	printBlankLine();
	cout << (int)(line + 1);
	cout << " | ";
	for (size_t i = 0; i < 8; i++)
	{
		cout << printPiece(line * 8 + i) << "  | ";
	}
	cout << (int)(line + 1) << endl;
	printBottomLine();
}

void Game::printBlankLine() const
{
	cout << "  |     "
		<< "|     "
		<< "|     "
		<< "|     "
		<< "|     "
		<< "|     "
		<< "|     "
		<< "|     |" << endl;
}

void Game::printTopLine() const
{
	cout << "   _______________________________________________" << endl;

}

void Game::printBottomLine() const
{
	cout << "  |_____"
		<< "|_____"
		<< "|_____"
		<< "|_____"
		<< "|_____"
		<< "|_____"
		<< "|_____"
		<< "|_____|" << endl;
}

void Game::printFileLabels() const
{
	cout << "     A  "
		<< "   B  "
		<< "   C  "
		<< "   D  "
		<< "   E  "
		<< "   F  "
		<< "   G  "
		<< "   H   " << endl;
}

string Game::printPiece(int pos) const
{
	auto it = find_if(Pieces.begin(), Pieces.end(), [pos](Piece p) {return p.getPos() == pos; });
	if (it == Pieces.end())
	{
		return "  ";
	}
	string output;

	cout << (it->getColor() == Piece::white ? "w" : "b");
	switch (it->getType())
	{
	case Piece::king:
		output.append("K");
		break;
	case Piece::queen:
		output.append("Q");
		break;
	case Piece::rook:
		output.append("R");
		break;
	case Piece::knight:
		output.append("N");
		break;
	case Piece::bishop:
		output.append("B");
		break;
	case Piece::pawn:
		output.append("P");
		break;
	default:
		output.append("?");
		break;
	}
	return output;
}