#pragma once
#include "Piece.h"
#include <vector>
#include <list>
#include <algorithm>

// list of pieces as they would be at the start of the game
static list<Piece> startPosition
{
	Piece(Piece::white,Piece::rook,Square(0)),
	Piece(Piece::white,Piece::knight,Square(1)),
	Piece(Piece::white,Piece::bishop,Square(2)),
	Piece(Piece::white,Piece::queen,Square(3)),
	Piece(Piece::white,Piece::king,Square(4)),
	Piece(Piece::white,Piece::bishop,Square(5)),
	Piece(Piece::white,Piece::knight,Square(6)),
	Piece(Piece::white,Piece::rook,Square(7)),
	Piece(Piece::black,Piece::rook,Square(56)),
	Piece(Piece::black,Piece::knight,Square(57)),
	Piece(Piece::black,Piece::bishop,Square(58)),
	Piece(Piece::black,Piece::queen,Square(59)),
	Piece(Piece::black,Piece::king,Square(60)),
	Piece(Piece::black,Piece::bishop,Square(61)),
	Piece(Piece::black,Piece::knight,Square(62)),
	Piece(Piece::black,Piece::rook,Square(63)),
		Piece(Piece::white,Piece::pawn,Square(8)),
		Piece(Piece::white,Piece::pawn,Square(9)),
		Piece(Piece::white,Piece::pawn,Square(10)),
		Piece(Piece::white,Piece::pawn,Square(11)),
		Piece(Piece::white,Piece::pawn,Square(12)),
		Piece(Piece::white,Piece::pawn,Square(13)),
		Piece(Piece::white,Piece::pawn,Square(14)),
		Piece(Piece::white,Piece::pawn,Square(15)),
		Piece(Piece::black,Piece::pawn,Square(48)),
		Piece(Piece::black,Piece::pawn,Square(49)),
		Piece(Piece::black,Piece::pawn,Square(50)),
		Piece(Piece::black,Piece::pawn,Square(51)),
		Piece(Piece::black,Piece::pawn,Square(52)),
		Piece(Piece::black,Piece::pawn,Square(53)),
		Piece(Piece::black,Piece::pawn,Square(54)),
		Piece(Piece::black,Piece::pawn,Square(55)),
};

class Game
{
public:
	// enums
	enum STATUS
	{
		WhiteToMove,
		BlackToMove,
		Checkmate,
		Draw
	};

	// constructors
	Game(const list<Piece>& pieces = startPosition, const vector<Move>& history = {}, STATUS status = WhiteToMove, unsigned int ply = 0);

	// setters and getters
	void setPieces(const list<Piece>& pieces);
	list<Piece> getAllPieces() const;
	list<Piece> getWhitePieces() const;
	list<Piece> getBlackPieces() const;
	vector<Square> getPositions() const;
	void setHistory(const vector<Move>& history);
	vector<Move> getHistory() const;
	void setStatus(STATUS status);
	STATUS getStatus() const;
	void setPly(unsigned int ply);
	unsigned int getPly() const;
	void setLegalMoves(Piece&);

	// retrun true if a player is in check
	bool inCheck(Piece::Color) const;

	// move pieces around
	void makeMove(const Move&);
	Game makeTestMove(const Move&) const;
	int validateMove(const Move&);

	// add and remove pieces
	void addPiece(const Piece&);
	void removePiece(const Piece&);
	void promotePiece(Piece&);

	// generate list of possible moves for a player
	vector<Move> getPseudoMoves(const Piece::Color player) const;
	vector<Move> getLegalMoves(const Piece::Color player) const;

	// update game state
	void updateMoves();
	void updateStatus();

	// display functions
	void printBoard() const;
	void printLine(int) const;
	void printBlankLine() const;
	void printTopLine() const;
	void printBottomLine() const;
	void printFileLabels() const;
	string printPiece(int) const;

private:
	unsigned int ply; // number of turns in the game
	STATUS status; // current game status
	vector<Move> history; // moves made in the game
	list<Piece> Pieces; // list of pieces on the board
};

