// Final Project.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
#include <stdexcept>
#include "Game.h"
constexpr auto DEBUG = false;
using namespace std;
void reset(Game&);
int getInput(Move&);
void debugMove(Game& game, const Move& move);

int main()
{
#if DEBUG // Square class debugger
	{
		cout << "\nSQAURE DEBUGGER";
		cout << "\nThis should print c4: " << Square::int_to_str(26);
		cout << "\nThis should print 63: " << Square::char_to_int('h', '8');
		cout << "\nThis should print 42: " << Square::str_to_int("c6");
		Square test1("d3");
		cout << "\nThis should print d3: " << static_cast<string>(test1);
		cout << "\nThis should print  4: " << test1.getFile();
		cout << "\nThis should print  3: " << test1.getRank();
		cout << "\nThis should print d5: " << static_cast<string>(test1.shift(Square::N, 2));
		cout << "\nThis should print h7: " << static_cast<string>(test1.shift(Square::NE, 4));
		cout << "\nThis should print e3: " << static_cast<string>(test1.shift(Square::E));
		cout << "\nThis should print f1: " << static_cast<string>(test1.shift(Square::SE, 2));
		cout << "\nThis should print d2: " << static_cast<string>(test1.shift(Square::S, 1));
		cout << "\nThis should print b1: " << static_cast<string>(test1.shift(Square::SW, 2));
		cout << "\nThis should print a3: " << static_cast<string>(test1.shift(Square::W, 3));
		cout << "\nThis should print a6: " << static_cast<string>(test1.shift(Square::NW, 3));
		Square test2("d3");
		Square test3("f6");
		cout << boolalpha << "\nSquares test1 and test2 are the same: " << (test1 == test2);
		cout << boolalpha << "\nSquares test1 and test3 are the same: " << (test1 == test3);
		try
		{
			test1.shift(Square::N, 6);
		}
		catch (const std::exception& e)
		{
			cout << endl << e.what();
		}
#endif // Move class debugger

#if DEBUG // Move class debugger
		cout << "\nMOVE DEBUGGER";
		try
		{
			Move firstMove("a1a1");
			Move secondMove('e', '1', 'd', '2');
			cout << boolalpha;
			cout << "\nshould return true: " << firstMove.validateNotation("c4f6");
			cout << "\nshould return false: " << firstMove.validateNotation("z4f6");
			cout << "\nshould return false: " << firstMove.validateNotation("c9f6");
			cout << "\nshould return false: " << firstMove.validateNotation("c4l6");
			cout << "\nshould return false: " << firstMove.validateNotation("c4f0");
			cout << "\nshould return false: " << firstMove.validateNotation("1111");
			cout << "\nshould return false: " << firstMove.validateNotation("c4f6c1b8");
			cout << endl << firstMove.toString();
			cout << endl << secondMove.toString();

			Move badMove("foo");
		}
		catch (const std::exception& e)
		{
			cout << endl << e.what();
		}
#endif // Move class debugger

#if DEBUG // piece class debugger
		cout << "\nPIECE DEBUGGER";
		try
		{
			Piece whiteKing(Piece::white, Piece::king, Square("e3"));
			Piece whiteQueen(Piece::white, Piece::queen, Square("c4"));
			Piece blackKing(Piece::black, Piece::king, Square("e8"));
			Piece whiteRook(Piece::white, Piece::rook, Square("e4"));
			Piece blackBishop(Piece::black, Piece::bishop, Square("f8"));
			Piece blackKnight(Piece::black, Piece::knight, Square("f4"));
			Piece whitePawn(Piece::white, Piece::pawn, Square("g2"));
			Piece whitePawn2(Piece::white, Piece::pawn, Square("c2"));
			Piece blackPawn(Piece::black, Piece::pawn, Square("f3"));
			list<Piece> example
			{
				whiteKing,
				whiteQueen,
				whiteRook,
				whitePawn,
				whitePawn2,
				blackKing,
				blackBishop,
				blackKnight,
				blackPawn
			};
			for (auto& piece : example)
			{
				piece.generateMoves(example);
				piece.displayInfo();
			}
			whiteKing.setPos(Square("jir"));
		}
		catch (const std::exception& e)
		{
			cout << endl << e.what();
		}
#endif // Piece class debugger

#if DEBUG // game class debugger
		Game newGame;
		// newGame.addPiece(Piece(Piece::black, Piece::knight, Square("c5")));
		list<Piece> startingWhitePieces = newGame.getWhitePieces();
		list<Piece> startingBlackPieces = newGame.getBlackPieces();

		cout << "Initial position" << endl;
		newGame.printBoard();
		//cout << "\n\nAfter first move" << endl;
		//newGame.makeMove(Move("f2f3"));
		//newGame.print();
		if (true) // simulate checkmate
		{
			debugMove(newGame, Move("f2f3"));
			debugMove(newGame, Move("e7e5"));
			debugMove(newGame, Move("g2g3"));
			debugMove(newGame, Move("d8h4"));
		}
		if (false) // simulate piece capture
		{
			debugMove(newGame, Move("e2e4"));
			debugMove(newGame, Move("e7e5"));
			debugMove(newGame, Move("d2d4"));
			debugMove(newGame, Move("e5d4"));
		}
		cout << "\nThe white king is in check: ";
		cout << boolalpha << newGame.inCheck(Piece::white) << endl;
		cout << "White has been checkmated: ";
		cout << boolalpha << newGame.isCheckmate() << endl;
		cout << "\nMake an invalid move";
		try
		{
			newGame.makeMove(Move("a1g6"));
		}
		catch (const std::exception& e)
		{
			cout << e.what();
		}
		try
		{
			newGame.makeMove(Move("e7e5"));
		}
		catch (const std::exception& e)
		{
			cout << e.what();
		}
		/*vector<Move> whiteMoves = newGame.getMoves(Piece::white);
		vector<Move> blackMoves = newGame.getMoves(Piece::black);
		cout << "White's psuedolegal moves are: " << endl;
		for (auto& move : whiteMoves)
		{
			cout << move.toString() << endl;
		}
		cout << "Black's psuedolegal moves are: " << endl;
		for (auto& move : blackMoves)
		{
			cout << move.toString() << endl;
		}*/
#endif // Game class debugger

		Game game;
		Move move{ 0,0 };
		game.printBoard();
		while (cin.good())
		{
			if (game.getStatus() == Game::WhiteToMove || game.getStatus() == Game::BlackToMove)
			{
				try
				{
					int response = getInput(move);
					if (response == 0)
					{
						game.makeMove(move);
						game.printBoard();
					}
					else if (response == 2)
					{
						for (auto& piece : game.getAllPieces())
						{
							piece.displayInfo();
						}
					}
					else if (response == 1)
					{
						reset(game);
						game.printBoard();
					}

				}
				catch (const std::exception& e)
				{
					std::cout << e.what();
				}
			}
			else
			{
				if (game.getStatus() == Game::Checkmate)
				{
					std::cout << (game.getPly() % 2 == 0 ? "\nWhite" : "\nBlack") << " has been checkmated!";
				}
				if (game.getStatus() == Game::Draw)
				{
					std::cout << "\nGame ends in a draw.";
				}
				std::cout << "\nWould you like to play again? (Y/N)\n? ";
				char response;
				while (cin >> response) {
					if (response == 'N')
					{
						exit(1);
					}
					if (response == 'Y')
					{
						reset(game);
						game.printBoard();
						break;
					}

					std::cout << "? ";
				}
			}
		}
}

	void reset(Game & game) {
		Game newGame;
		game = newGame;
	}

	int getInput(Move & move) {
		string input;
		std::cout << "\nEnter a move. R to restart. EOF to quit.\n? ";
		cin >> input;
		if (cin.eof())
		{
			exit(0);
		}
		if (input == "D")
		{
			return 2;
		}
		if (input == "R")
		{
			return 1;
		}
		if (Move::validateNotation(input))
		{
			move = input;
			return 0;
		}
		else
		{
			throw invalid_argument("Incorrect notation, use algebraic notation. For example e2e4");
		}
	}

	void debugMove(Game & game, const Move & move)
	{
		try
		{
			game.makeMove(move);
			std::cout << "\nAfter move  " << move.toString() << endl;
			game.printBoard();
		}
		catch (const std::exception& e)
		{
			std::cout << e.what();
		}
	};