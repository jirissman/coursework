// MAIN PROGRAM
// A program to manipulate a few jar objects

// Edit History:
// 9/27/22 JR Created main program file
// 10/06/22 JR Added jar4, jar5, jar6 and getInput function
// 10/13/22 JR Changed getInput function to a template function
// 10/13/22 JR Added shelf array with 3 jars and a function that adds random amounts to each jar

#include "jar.h"
#include <iostream>
#include <cstdlib>

template <typename T>
T getInput(T& n);  // The prototype, appears before main()

// int getInput(int& n); // depreciated getInput function

int main() {
	JarType jar1, jar2;

	// Removed the next line as it causes a compilation error
	// jar1.numUnits = 10000;

	jar1.initToEmpty(); // initialize jar1 to empty
	jar2.initToEmpty(); // initialize jar2 to empty

	jar1.add(10);
	jar2 = jar1;
	jar2.add(5);

	std::cout << "\nJar1 contains " << jar1.quantity(); // print jar1 contents
	std::cout << "\nJar2 contains " << jar2.quantity(); // print jar2 contents
	std::cout << std::endl;

	JarType jar3(50); // initialize jar3 to 50
	std::cout << "\nJar3 contains " << jar3.quantity(); // print jar3 contents
	std::cout << std::endl;

	jar1.add(-5000);
	jar2.sub(-100);

	JarType jar4('p');	// Prefill with 16 ounces
	JarType jar5('q');	// Prefill with 32 ounces
	JarType jar6('a');	// Should print invalid request.

	std::cout << "\nJar4 contains " << jar4.quantity(); // print jar4 contents
	std::cout << "\nJar5 contains " << jar5.quantity(); // print jar5 contents
	std::cout << std::endl;

	jar6.initToEmpty();
	int number = 0;

	// Get a number from the user to add to jar6.
	int status = getInput(number);
	// Be sure the number is "good".
	if (status == 0)
	{
		jar6.add(number);
	}
	std::cout << "\nJar6 contains " << jar6.quantity() << std::endl;

	JarType shelf[3]{jar1,jar2,jar3};
	srand(static_cast<unsigned int>(time(0)));
	for (auto& jar : shelf)
	{
		static int i;
		jar.add(rand() % 100);
		std::cout << "\nShelf position " << ++i << " contains " << jar.quantity() << std::endl;
	}

	return 0; // Success
} // end of main()

template <typename T>
T getInput(T& n)
{
	T temp;

	std::cout << "Please enter number of units: ";

	std::cin >> temp;

	if (temp > 0)
	{
		n = temp;
		return 0;
	}
	return 1;
} // end of getInput()


/* Depreciated getInput fucntion
// Description:  A function to ask user for a value
// Return status: 0  a valid number is entered
//                1  a valid number is not entered
 int getInput(int& n)
{
	int temp;

	std::cout << "\nPlease enter number of units: ";

	std::cin >> temp;

	if (temp > 0)
	{
		n = temp;
		return 0;
	}
	return 1;
} // end of getInput() */