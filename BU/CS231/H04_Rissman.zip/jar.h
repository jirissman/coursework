#pragma once
// SPECIFICATION FILE
// Declare the abstract data type JarType

// Edit History:
// 9/27/22 JR Created specification file
// 10/6/22 JR Added new JarType constructor with pint and quart options

#ifndef JAR_H
#define JAR_H

class JarType {
public:
	JarType();            // Constructor
	JarType(int n);       // Another constructor
	JarType(char n);	  // Pint & Quart constructor
	~JarType();           // Destructor
	void initToEmpty();   // Initialize a jar
	void add(int n);      // Add n units to jar
	void sub(int n);      // Subtract n units from jar
	int quantity() const; // Reveal number of units in jar
private:
	int numUnits;
};

#endif // !JAR_H