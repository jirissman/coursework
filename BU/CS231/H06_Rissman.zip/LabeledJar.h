#pragma once
// SPECIFICATION FILE
// Declare the abstract data type LabeledJar

// Edit History:
// 11/02/2022 JR Created specification file

#include "jar.h"
#include <string>
using namespace std;
class LabeledJar: public JarType
{
public:
	LabeledJar();					// Constructor
	LabeledJar(int n);				// Constructor
	LabeledJar(string lbl);			// Constructor
	LabeledJar(string lbl, int n);	// Constructor
	~LabeledJar();					// Destructor
	string getLabel() const;

private:
	string label;
};

