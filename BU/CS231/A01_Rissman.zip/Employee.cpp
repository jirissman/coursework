// Edit History
// 10/09/22 JR Created implementation file
// 10/10/22 JR renamed method

#include "Employee.h"
#include <iostream>
#include <string>
using namespace std;

Employee::Employee(const string& fn, const string& ln, double pay) // Custom constructor
{
	firstName = fn;
	lastName = ln;
	salary = (pay > 0) ? pay : 0;
}

void Employee::setName(const string& fn, const string& ln)
{
	firstName = fn;
	lastName = ln;
}

void Employee::setSalary(double pay)
{
	if (pay >= 0)
	{
		salary = pay;
	}

}

string Employee::getFullName() const
{
	string fullName{ firstName + " " + lastName };
	return string(fullName);
}

double Employee::getSalary() const
{
	return salary;
}
