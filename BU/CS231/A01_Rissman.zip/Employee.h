// SPECIFICATION FILE
// Declare the abstract data type Employee

// Edit History
// 10/09/22 JR Created header file

#pragma once
#include <iostream>
#include <string>
using namespace std;

#ifndef EMPLOYEE
#define EMPLOYEE

class Employee
{
public:
	Employee(const string& fn, const string& ln, double pay);	// Custom constructor
	void setName(const string& fn, const string& ln); // requires first & last names
	void setSalary(double pay); // must be positive
	string getFullName() const; // returns full name
	double getSalary() const; // get monthly salary

private:
	string firstName;
	string lastName;
	double salary;			// employee monthly salary
};

#endif // !EMPOYEE