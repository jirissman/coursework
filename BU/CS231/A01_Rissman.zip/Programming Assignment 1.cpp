// Programming Assignment 1.cpp : This file contains the 'main' function. Program execution begins and ends there.
// EDIT HISTORY
// 10/09/22 JR Created main file
// 10/10/22 JR removed setNewSalary function; changed giveRaise parameter to percent

#include <iostream>
#include "Employee.h"
using namespace std;

void giveRaise(Employee& employee, double percent);
void displayInfo(const Employee employee);

int main()
{
    Employee e1("John", "Doe", 1234.56);
    Employee e2("Jane", "Jones", 7890.12);

    displayInfo(e1);
    displayInfo(e2);

    giveRaise(e1, 10);
    giveRaise(e2, 10);

    e2.setName("Jane", "Doe");
    e2.setSalary(-200); // should do nothing

    displayInfo(e1); 
    displayInfo(e2);
}

// function to give an employee a permanent raise by a given percent
// input: Employee object reference, percent raise
// output: sets new salary for employee
void giveRaise(Employee& employee, double percent)
{
    employee.setSalary(employee.getSalary() * (1 + percent / 100));
    displayInfo(employee); // print new salary
}

// prints message with employee name and yearly salary
// input: Employee object
// output: prints employee information
void displayInfo(const Employee employee)
{
    cout << "\nEmployee " << employee.getFullName() << " has a yearly salary of " << employee.getSalary() * 12 << endl;
}