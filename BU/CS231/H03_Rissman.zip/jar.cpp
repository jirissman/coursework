// IMPLEMENTATION FILE
// Implement the abstract data type JarType\

// Edit History:
// 2/27/22 JR Created implementation file

#include "jar.h"
#include <iostream>
using namespace std;

void JarType::initToEmpty() {
	numUnits = 0;
}

void JarType::add(int n) {
	if (n > 0)
	{
		numUnits += n;
	}
	else
	{
		cout << "\nEnter a positive number" << endl;
	}
}

void JarType::sub(int n) {
	if (n > 0)
	{
		(n > numUnits) ? numUnits = 0 : numUnits -= n;
	}
	else
	{
		cout << "\nEnter a positive number" << endl;
	}
}

int JarType::quantity() const {
	return numUnits;
}

JarType::JarType() {
	numUnits = 0;
	cout << "\nRinsing jar..." << endl;
}

JarType::JarType(int n) {
	numUnits = n;
	cout << "\nPrefill jar with " << numUnits << endl;
}

JarType::JarType(char n)
{
	switch (n)
	{
	case 'p':
		numUnits = 16;
		break;
	case 'q':
		numUnits = 32;
		break;
	default:
		cerr << "\nInvalid Request" << endl;
		break;
	}
}

JarType::~JarType() {
	cout << "\nDestroying jar" << endl;
}