// MAIN PROGRAM
// A program to manipulate a few jar objects

// Edit History:
// 2/27/22 JR Created main program file

#include "jar.h"
#include <iostream>

int main() {
	JarType jar1, jar2;

	// Removed the next line as it causes a compilation error
	// jar1.numUnits = 10000;

	jar1.initToEmpty(); // initialize jar1 to empty
	jar2.initToEmpty(); // initialize jar2 to empty

	jar1.add(10);
	jar2 = jar1;
	jar2.add(5);

	std::cout << "\nJar1 contains " << jar1.quantity(); // print jar1 contents
	std::cout << "\nJar2 contains " << jar2.quantity(); // print jar2 contents
	std::cout << std::endl;

	JarType jar3(50); // initialize jar3 to 50
	std::cout << "\nJar3 contains " << jar3.quantity(); // print jar3 contents
	std::cout << std::endl;

	jar1.add(-5000);
	jar2.sub(-100);

	return 0; // Success
} // end of main()