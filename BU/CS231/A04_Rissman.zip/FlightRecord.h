#pragma once
#include <string>
#include <iostream>
using namespace std;


class FlightRecord
{
public:
	FlightRecord(const string&); // flight record constructor with field delimited by ','
	void displayRecord() const;
private:
	string flightNumber;
	string originAirport;
	string destinationAirport;
	string numberPassengers;
	string averagePrice;
};

