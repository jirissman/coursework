#include "FlightRecord.h"

FlightRecord::FlightRecord(const string& input)
{
    int start = 0;
    int end;
    end = input.find(',', start);
    
    flightNumber = input.substr(start, (end - start));

    start = end + 1; // pass the ","
    end = input.find(',', start);
    originAirport = input.substr(start, (end - start));

    start = end + 1; // pass the ","
    end = input.find(',', start);
    destinationAirport = input.substr(start, (end - start));

    start = end + 1; // pass the ","
    end = input.find(',', start);
    numberPassengers = input.substr(start, (end - start));

    start = end + 1; // pass the ","
    end = input.size();
    averagePrice = input.substr(start, (end - start));

}

void FlightRecord::displayRecord() const
{
    cout << "Flight Number: " << flightNumber;
    cout << "\nOrigin Airport: " << originAirport;
    cout << "\nDestination Airport: " << destinationAirport;
    cout << "\nNumber of Passengers: " << numberPassengers;
    cout << "\nAverage Price: " << averagePrice << endl;
}
