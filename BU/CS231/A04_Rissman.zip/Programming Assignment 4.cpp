// Programming Assignment 4.cpp
// Name: Joseph Rissman
// Course: CS231
// Due Date: 11/05/22

#include <iostream>
#include <fstream>
#include <string>
#include "FlightRecord.h"
using namespace std;


int main()
{
	string filepath = "C:\\Users\\jiris\\source\\repos\\Programming Assignment 4\\flightdata.txt"; // file path for Windows
	ifstream flightData(filepath);

	if (!flightData.good())
	{
		cout << "Could not open/access file.";
		return 1;
	}
	cout << "Enter N to see next record. Enter any other character to exit.\n? ";
	char input;
	while (cin >> input)
	{
		if (input != 'n' && input != 'N')
		{
			return 0;
		}
		string lineOfData;
		getline(flightData, lineOfData);
		FlightRecord record(lineOfData);
		record.displayRecord();
		if (flightData.eof())
		{
			cout << "End-of-file reached.";
			return 0;
		}
		cout << "? ";
	}
}