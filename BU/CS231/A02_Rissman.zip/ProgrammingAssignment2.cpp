// ProgrammingAssignment2.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Name: Joseph Rissman
// Course: CS231
// Due Date: 10/31/22


#include <iostream>
#include "DataArray.h"

int main()
{
    DataArray numbers1(vector<float>{1.23, 2.34, 3.45, 4.56, 5.67});
    DataArray numbers2(vector<float>{100,200,300,400,500,600,700,800,900,1000});
    DataArray numbers3(vector<float>{10.123,20.234,30.345,40.456,50.567});
    DataArray numbers4(vector<float>{1,1,1,1,1});
    DataArray numbers5(vector<float>{1,2,3,4,5,6,7,8,9,10});
    DataArray numbers6; // empty array to get user input

    cout << numbers1;
    numbers1.displayStats();
    cout << numbers2;
    numbers2.displayStats();
    cout << numbers3;
    numbers3.displayStats();
    cout << numbers4;
    numbers4.displayStats();
    cout << numbers5;
    numbers5.displayStats();

    numbers6.getData();
    cout << numbers6;
    numbers6.displayStats();


}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
