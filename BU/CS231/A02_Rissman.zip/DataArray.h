#pragma once
#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

class DataArray
{
	friend std::ostream& operator<<(std::ostream& os, const DataArray& arr); // overload operator <<
public:
	DataArray();					// default constructor
	DataArray(vector<float> arr);	// construct with existing data
	~DataArray();					// destructor
	void getData();					// input data from user
	float average() const;			// calculate average
	float stdDev() const;			// calculate sample standard deviation
	void displayStats() const;		// display average and standard deviation
private:
	vector<float> data;
};

