#include "DataArray.h"
#include <vector>
#include <iostream>
#include <cmath>
using namespace std;

DataArray::DataArray() {
	
}

DataArray::DataArray(vector<float> arr) {
	data = arr;
}

DataArray::~DataArray() {

}

void DataArray::getData() {
	float input{0};
	int i{0};

	cout << "\nPlease enter up to 100 numbers. Enter any non-number value to break." << endl;
	cout << "Enter numbers: " << endl;
	do
	{
		cin >> input;
		if (cin.fail())
		{
			cout << "Data saved." << endl;
			i = 100;
		}
		else
		{
			data.push_back(input);
			i++;
		}
	} while (i < 100);
}

float DataArray::average() const {
	float total{ 0 };
	for (auto& i : data)
	{
		total += i;
	}
	return total / data.size();
}

float DataArray::stdDev() const {
	float avg{ this->average() };
	float sum{ 0 };
	for (auto& i : data)
	{
		sum += pow((i - avg), 2);
	}
	return sqrt(sum / (data.size() - 1));
}

void DataArray::displayStats() const {
	cout << "\nThe average is: " << this->average() 
		<< "\nThe sample standard deviation is: " << this->stdDev() 
		<< "\nThe array size is: " << data.size() << endl;
}

std::ostream& operator<<(std::ostream& os, const DataArray& arr) {
	os << "\nThe array of numbers is: " << endl;
	for (auto& i : arr.data)
	{
		os << i << endl;
	}
	return os;
}