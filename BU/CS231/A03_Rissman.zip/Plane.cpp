#include "Plane.h"
#include <stdexcept>
#include <iomanip>
#include <sstream>

Plane::Plane(const string& make, const string& model, unsigned int year, double price, unsigned int seats, unsigned int engines)
	:Vehicle(make, model, year, price)
{
	setSeats(seats);
	setEngines(engines);
}

void Plane::setSeats(unsigned int seats)
{
	if (seats < 1)
	{
		throw invalid_argument("Planes must have at least one seat");
	}

	m_seats = seats;
}

unsigned int Plane::getSeats() const
{
	return m_seats;
}

void Plane::setEngines(unsigned int engines)
{
	if (engines <= 0)
	{
		throw invalid_argument("Planes must have at least one engine");
	}

	m_engines = engines;
}

unsigned int Plane::getEngines() const
{
	return m_engines;
}

string Plane::toString() const
{
	ostringstream output;
	output << Vehicle::toString()
		<< "\nSeats: " << getSeats()
		<< "\nEngines: " << getEngines();
	return output.str();
}

void Plane::start() const
{
	cout << "\nHow to start a plane:"
		<< "\n1. Fasten seat belts"
		<< "\n2. Check the circuit breakers"
		<< "\n3. Verify avionics master is off"
		<< "\n4. Open the throttle by 1/4 inch"
		<< "\n5. Set the mixture to \"Idle Cuttoff\""
		<< "\n6. Turn the master switch ON"
		<< "\n7. Verify the carburetor heat is cold"
		<< "\n8. Pump the primer 1 to 5 times"
		<< "\n9. Engage the starter";
}

void Plane::displayWindowSticker() const
{
	cout << toString();
}
