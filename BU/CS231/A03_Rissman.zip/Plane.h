#pragma once
#include "Vehicle.h"

class Plane :
    public Vehicle
{
public:
    // constructor
    Plane(const string&, const string&, unsigned int = 2000, double = 0.0, unsigned int = 1, unsigned int = 1);

    // setters and getters
    void setSeats(unsigned int);
    unsigned int getSeats() const;
    void setEngines(unsigned int);
    unsigned int getEngines() const;

    // output string
    string toString() const;

    // display information to start the vehicle
    virtual void start() const override;

    // override output function
    virtual void displayWindowSticker() const override;

private:
    unsigned int m_seats;
    double m_engines;
};

