#include "Truck.h"
#include <stdexcept>
#include <iomanip>
#include <sstream>

Truck::Truck(const string& make, const string& model, unsigned int year, double price, unsigned int axles, double capacity)
	:Vehicle(make, model, year, price)
{
	setAxles(axles);
	setCapacity(capacity);
}

void Truck::setAxles(unsigned int axles)
{
	if (axles < 2)
	{
		throw invalid_argument("Trucks must have at least 2 axles");
	}

	m_axles = axles;
}

unsigned int Truck::getAxles() const
{
	return m_axles;
}

void Truck::setCapacity(double capacity)
{
	if (capacity <= 0)
	{
		throw invalid_argument("Cargo capacity must be positive");
	}

	m_capacity = capacity;
}

double Truck::getCapacity() const
{
	return m_capacity;
}

string Truck::toString() const
{
	ostringstream output;
	output << Vehicle::toString()
		<< "\nAxles: " << getAxles()
		<< "\nCapacity: " << getCapacity() << " lbs";
	return output.str();
}

void Truck::start() const
{
	cout << "\nHow to start a truck:"
		<< "\n1. Put the key in the ignition"
		<< "\n2. Turn the key in the ignition"
		<< "\n3. Honk the horn";
}

void Truck::displayWindowSticker() const
{
	cout << toString();
}