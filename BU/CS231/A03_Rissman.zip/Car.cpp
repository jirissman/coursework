#include "Car.h"
#include <stdexcept>
#include <iomanip>
#include <sstream>

Car::Car(const string& make, const string& model, unsigned int year, double price, unsigned int doors, double mpg)
	:Vehicle(make, model, year, price)
{
	setDoors(doors);
	setMPG(mpg);
}

void Car::setDoors(unsigned int doors)
{
	if (doors < 1)
	{
		throw invalid_argument("Cars must have doors");
	}

	m_doors = doors;
}

unsigned int Car::getDoors() const
{
	return m_doors;
}

void Car::setMPG(double mpg)
{
	if (mpg <= 0)
	{
		throw invalid_argument("MPG must be positive");
	}

	m_mpg = mpg;
}

double Car::getMPG() const
{
	return m_mpg;
}

string Car::toString() const
{
	ostringstream output;
	output << Vehicle::toString()
		<< "\nDoors: " << getDoors()
		<< "\nMPG: " << getMPG();
	return output.str();
}

void Car::start() const
{
	cout << "\nHow to start a car:"
		<< "\n1. Put the key in the ignition"
		<< "\n2. Turn the key in the ignition";
}

void Car::displayWindowSticker() const
{
	cout << toString();
}
