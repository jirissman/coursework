#pragma once
#include "Vehicle.h"

class Truck :
    public Vehicle
{
public:
    // constructor
    Truck(const string&, const string&, unsigned int = 2000, double = 0.0, unsigned int = 4, double = 1.0);

    // setters and getters
    void setAxles(unsigned int);
    unsigned int getAxles() const;
    void setCapacity(double);
    double getCapacity() const;

    // output string
    string toString() const;

    // display information to start the vehicle
    virtual void start() const override;

    // override output function
    virtual void displayWindowSticker() const override;

private:
    unsigned int m_axles;
    double m_capacity; // capacity in pounds
};

