#pragma once
// CS231 - Programming Assignment 3
// Due 11/21/22
// Joseph Rissman

#include <string>
#include <iostream>
using namespace std;

class Vehicle
{
public:
	// constructors
	Vehicle(const string&, const string&, unsigned int = 2000, double = 0.0);
	
	// setters and getters
	void setMake(const string&);
	string getMake() const;
	void setModel(const string&);
	string getModel() const;
	void setYear(unsigned int);
	unsigned int getYear() const;
	void setPrice(double);
	double getPrice() const;

	// format contents as string
	string toString() const;

	// display information to start the vehicle
	virtual void start() const;

	// display vehicle information
	virtual void displayWindowSticker() const;
private:
	string m_make;
	string m_model;
	unsigned int m_year;
	double m_price;
};

