// Programming Assignment 3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>
#include <array>
#include "Car.h"
#include "Truck.h"
#include "Plane.h"
using namespace std;

int main()
{

    Car myCar("Honda", "Civic");
	try
	{
		myCar.setDoors(4);
		myCar.setMPG(30);
		myCar.setYear(2020);
		myCar.setPrice(25'000);
		Car dreamCar("Jaguar","F-TYPE",2022,73400,2,24);
		Truck myTruck("Freightliner", "Cascadia", 2021, 161000, 9, 65000);
		Truck fancyTruck("Mercedes-Benz", "Actros", 2022, 250'000, 8, 52000);
		Plane commericalPlane("Boeing", "737-700", 2018, 89'100'000, 126, 2);
		Plane usedPlane("Cessna", "P210N", 1979, 285'000, 2, 1);
		array <Vehicle*, 6> hangar = { &myCar,&dreamCar,&myTruck,&fancyTruck,&commericalPlane,&usedPlane };
		for (auto& i : hangar)
		{
			i->displayWindowSticker();
			i->start();
		}
	}
	catch (const std::exception& e)
	{
		cout << e.what();
	}

}