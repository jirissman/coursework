#include "Vehicle.h"
#include <iomanip>
#include <sstream>
#include <stdexcept>

Vehicle::Vehicle(const string& make, const string& model, unsigned int year, double price)
	:m_make{ make }, m_model{ model }
{
	setYear(year); // validate input
	setPrice(price); // validate input
}

void Vehicle::setMake(const string& make)
{
	m_make = make;
}

string Vehicle::getMake() const
{
	return m_make;
}

void Vehicle::setModel(const string& model)
{
	m_model = model;
}

string Vehicle::getModel() const
{
	return m_model;
}

void Vehicle::setYear(unsigned int year)
{
	if (year > 2022)
	{
		throw invalid_argument("Invalid Year");
	}

	m_year = year;
}

unsigned int Vehicle::getYear() const
{
	return m_year;
}

void Vehicle::setPrice(double price)
{
	if (price < 0)
	{
		throw invalid_argument("Price must be >= 0");
	}

	m_price = price;
}

double Vehicle::getPrice() const
{
	return m_price;
}

string Vehicle::toString() const
{
	ostringstream output;
	output << "\nMake: " << getMake()
		<< "\nModel: " << getModel()
		<< "\nYear: " << getYear()
		<< "\nPrice: " << fixed << setprecision(2) << getPrice();
	return output.str();
}

void Vehicle::start() const
{
	// will override in derived classes
}

void Vehicle::displayWindowSticker() const
{
	cout << toString();
}
