#pragma once
#include "Vehicle.h"

class Car :
    public Vehicle
{
public:
    // constructor
    Car(const string&, const string&, unsigned int = 2000, double = 0.0, unsigned int = 4, double = 1.0);

    // setters and getters
    void setDoors(unsigned int);
    unsigned int getDoors() const;
    void setMPG(double);
    double getMPG() const;

    // output string
    string toString() const;

    // display information to start the vehicle
    virtual void start() const override;

    // override output function
    virtual void displayWindowSticker() const override;

private:
    unsigned int m_doors;
    double m_mpg;
};

