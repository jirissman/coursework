#pragma once
// SPECIFICATION FILE
// Declare the abstract data type LabeledJar

// Edit History:
// 11/02/22 JR Created specification file
// 11/13/22 JR Added override of virtual function showInfo

#include "jar.h"
#include <string>
using namespace std;
class LabeledJar: public JarType
{
public:
	LabeledJar();					// Constructor
	LabeledJar(int n);				// Constructor
	LabeledJar(string lbl);			// Constructor
	LabeledJar(string lbl, int n);	// Constructor
	~LabeledJar();					// Destructor
	string getLabel() const;
	virtual void showInfo() const override;
private:
	string label;
};

