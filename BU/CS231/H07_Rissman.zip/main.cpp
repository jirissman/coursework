// MAIN PROGRAM
// A program to manipulate a few jar objects

// Edit History:
// 9/27/22 JR Created main program file
// 10/06/22 JR Added jar4, jar5, jar6 and getInput function
// 10/13/22 JR Changed getInput function to a template function
// 10/13/22 JR Added shelf array with 3 jars and a function that adds random amounts to each jar
// 10/22/22 JR Added jarPtr to use pointers
// 10/22/22 JR Added rack built-in array
// 10/22/22 JR Use copy constructor for jar31
// 10/22/22 JR Added friend function reveal
// 10/22/22 JR Added jarCount variable
// 11/02/22 JR Added LabeledJar functionality
// 11/13/22 JR Create array of jars & labeledjars and use virtual showInfo
// 11/13/22 JR Added warehouse of jars using unique_ptr

#include "jar.h"
#include "LabeledJar.h"
#include <iostream>
#include <cstdlib>
#include <stdexcept>
#include <memory>

template <typename T>
T getInput(T& n);  // The prototype, appears before main()

// int getInput(int& n); // depreciated getInput function

int reveal(JarType j); // friend function prototype

int JarType::jarCount = 0;  // Initialize the jar counter

int main() {
	std::cout << "Count of jars is: " << JarType::getJarCount() << std::endl;

	JarType jar1, jar2;

	std::cout << "After jar1 and jar2, count of jars is: " << JarType::getJarCount() << std::endl;

	// Removed the next line as it causes a compilation error
	// jar1.numUnits = 10000;

	jar1.initToEmpty(); // initialize jar1 to empty
	jar2.initToEmpty(); // initialize jar2 to empty

	jar1.add(10);
	jar2 = jar1;
	jar2.add(5);

	std::cout << "\nJar1 contains " << jar1.quantity(); // print jar1 contents
	std::cout << "\nJar2 contains " << jar2.quantity(); // print jar2 contents
	std::cout << std::endl;

	JarType jar3(50); // initialize jar3 to 50
	std::cout << "\nJar3 contains " << jar3.quantity(); // print jar3 contents
	std::cout << std::endl;

	try
	{
		jar1.add(-5000);
		cout << "\nCode should never reach here";
	}
	catch (const std::exception& e)
	{
		cout << e.what();
	}
	
	try
	{
		jar2.sub(-100);
		cout << "\nCode should never reach here";
	}
	catch (const std::exception& e)
	{
		cout << e.what();
	}

	JarType jar4('p');	// Prefill with 16 ounces
	JarType jar5('q');	// Prefill with 32 ounces
	JarType jar6('a');	// Should print invalid request.

	std::cout << "\nJar4 contains " << jar4.quantity(); // print jar4 contents
	std::cout << "\nJar5 contains " << jar5.quantity(); // print jar5 contents
	std::cout << std::endl;

	jar6.initToEmpty();
	int number = 0;

	// Get a number from the user to add to jar6.
	int status = getInput(number);
	// Be sure the number is "good".
	if (status == 0)
	{
		jar6.add(number);
	}
	std::cout << "\nJar6 contains " << jar6.quantity() << std::endl;

	JarType shelf[3]{jar1,jar2,jar3};
	srand(static_cast<unsigned int>(time(0)));
	for (auto& jar : shelf)
	{
		static int i;
		jar.add(rand() % 100);
		std::cout << "\nShelf position " << ++i << " contains " << jar.quantity() << std::endl;
	}

	JarType* jarPtr = nullptr;	// Define the pointer variable
	jarPtr = &jar1;	// Get address of jar1 -- a good statement (pointer to == address of)
	std::cout << "Showing quantities in jar1 via a pointer variable: " << jarPtr->quantity() << std::endl;

	JarType* rack = new JarType[5];
	rack[0].add(100);
	rack[1].add(200);
	rack[2].add(250);
	(rack + 3)->add(500);
	(rack + 4)->add(1000);
	for (size_t i = 0; i < 5; i++)
	{
		std::cout << "\nRack position " << i+1 << " contains " << rack[i].quantity();
	} std::cout << std::endl;
	delete[] rack;


	JarType jar31 = jar1;
	std::cout << "\nJar1 contains " << reveal(jar1); // print jar1 contents 
	

	std::cout << jar1; // overloaded << operator

	JarType jar30;
	jar30 = jar1 + jar2; // overloaded + operator
	std::cout << jar30;

	int xyz = jar1; // convert jar to int
	jar2 = xyz; 

	LabeledJar pills; // Create object "piils"
	pills.add(23);
	std::cout << "\nLabeled jar contains: " << pills.quantity() << " units." << std::endl;
	std::cout << "\nLabeled jar's label: " << pills.getLabel() << std::endl;

	LabeledJar pickles(25);  // Prefill 
	LabeledJar candy("Kit Kat"); // Create jar with label Kit Kat
	LabeledJar abc("Kit Kat", 25); // Create jar with label Kit Kat and prefill

	JarType* arrayOfJars[4];  // An array of pointers to "jars"
	// Now populate the array
	arrayOfJars[0] = &jar1;
	arrayOfJars[1] = &pickles;
	arrayOfJars[2] = &jar2;
	arrayOfJars[3] = &abc;

	for (int i = 0; i < 4; i++) {
		arrayOfJars[i]->showInfo();
	}

	const int arraySize = 10;
	unique_ptr< JarType[] > wareHouse(new JarType[arraySize]);

	// Add a few units to each jar
	for (size_t i = 0; i < arraySize; i++)
	{
		try
		{
			wareHouse[i].add(rand() % 10);
		}
		catch (const std::exception& e)
		{
			cout << e.what();
		}
	}

	// Show the quantities in each jar
	for (int i = 0; i < arraySize; i++) {
		cout << "  Item " << i << " has: " << wareHouse[i].quantity() << endl;
	}

	return 0; // Success
} // end of main()

template <typename T>
T getInput(T& n)
{
	T temp;

	std::cout << "Please enter number of units: ";

	std::cin >> temp;

	if (temp > 0)
	{
		n = temp;
		return 0;
	}
	return 1;
} // end of getInput()


/* Depreciated getInput fucntion
// Description:  A function to ask user for a value
// Return status: 0  a valid number is entered
//                1  a valid number is not entered
 int getInput(int& n)
{
	int temp;

	std::cout << "\nPlease enter number of units: ";

	std::cin >> temp;

	if (temp > 0)
	{
		n = temp;
		return 0;
	}
	return 1;
} // end of getInput() */

int reveal(JarType j) // friend function returns private data member
{
	return j.numUnits;
}


