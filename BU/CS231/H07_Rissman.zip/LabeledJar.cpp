// IMPLEMENTATION FILE
// Implement the abstract data type JarType\

// Edit History:
// 11/02/22 JR Created implementation file
// 11/13/22 JR Added override of virtual function showInfo

#include "LabeledJar.h"

LabeledJar::LabeledJar()
{
	label = "Generic";
	cout << "\nGetting labeled jar ready" << endl;
}

LabeledJar::LabeledJar(int n): JarType (n)
{
	label = "Generic";
	cout << "Getting labeled jar with custom constructor 1" << endl;
}

LabeledJar::LabeledJar(string lbl): JarType()
{
	label = lbl;
	cout << "Getting labeled jar with custom constructor 2" << endl;
}

LabeledJar::LabeledJar(string lbl, int n): JarType(n)
{
	label = lbl;
	cout << "Getting labeled jar with custom constructor 3" << endl;
}

LabeledJar::~LabeledJar()
{
	cout << "\nDestroying labeled jar" << endl;
}

string LabeledJar::getLabel() const
{
	return label;
}

void LabeledJar::showInfo() const
{
	cout << "\nThe jar labeled " << label << " contains " << quantity() << " units." << endl;
}
