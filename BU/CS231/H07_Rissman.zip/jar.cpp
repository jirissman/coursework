// IMPLEMENTATION FILE
// Implement the abstract data type JarType\

// Edit History:
// 09/27/22 JR Created implementation file
// 10/06/22 JR Added new JarType constructor with pint and quart options
// 10/22/22 JR Added copy constructor
// 10/22/22 JR Modified every constructor to increment jarCount and destructor to decrement jarCount
// 11/02/22 JR Added friend function operator<< to enable cout << JarType
// 11/02/22 JR Added member function operator+ to enable JarType + JarType
// 11/02/22 JR Added member function operator int() to convert JarType to int
// 11/13/22 JR Added virtual function showInfo
// 11/13/22 JR Modified add and sub methods to throw exceptions


#include "jar.h"
#include <iostream>
#include <stdexcept>

using namespace std;

std::ostream& operator<<(std::ostream& os, const JarType& j)
{
	os << "\nThe supplied jar contains " << j.quantity() << " units." << std::endl;
	return os;
}
void JarType::initToEmpty() {
	numUnits = 0;
}

void JarType::add(int n) {
	if (n >= 0)
	{
		numUnits += n;
	}
	else
	{
		throw invalid_argument("\nEnter a positive number");
	}
}

void JarType::sub(int n) {
	if (n >= 0)
	{
		(n > numUnits) ? numUnits = 0 : numUnits -= n;
	}
	else
	{
		throw invalid_argument("\nEnter a positive number");
	}
}

int JarType::quantity() const {
	return numUnits;
}

int JarType::getJarCount()
{
	return jarCount;
}

JarType JarType::operator+(const JarType& j)
{
	JarType tmpJar;
	tmpJar.add(this->numUnits + j.numUnits);
	return tmpJar;
}

JarType::operator int()
{
	return numUnits;
}

void JarType::showInfo() const
{
	cout << *this;
}

JarType::JarType() {
	numUnits = 0;
	jarCount++;
	cout << "\nRinsing jar..." << endl;
}

JarType::JarType(int n) {
	numUnits = n;
	jarCount++;
	cout << "\nPrefill jar with " << numUnits << endl;
}

JarType::JarType(char n)
{
	jarCount++;
	switch (n)
	{
	case 'p':
		numUnits = 16;
		break;
	case 'q':
		numUnits = 32;
		break;
	default:
		numUnits = 0;
		cerr << "\nInvalid Request" << endl;
		break;
	}
}

JarType::JarType(JarType& j)
{
	cout << "In Copy Constructor" << endl;
	jarCount++;
	numUnits = j.numUnits;
}

JarType::~JarType() {
	cout << "\nDestroying jar" << endl;
	jarCount--;
}