// IMPLEMENTATION FILE
// Implement the abstract data type JarType\

// Edit History:
// 09/27/22 JR Created implementation file
// 10/06/22 JR Added new JarType constructor with pint and quart options
// 10/22/22 JR Added copy constructor
// 10/22/22 JR Modified every constructor to increment jarCount and destructor to decrement jarCount

#include "jar.h"
#include <iostream>
using namespace std;

void JarType::initToEmpty() {
	numUnits = 0;
}

void JarType::add(int n) {
	if (n > 0)
	{
		numUnits += n;
	}
	else
	{
		cout << "\nEnter a positive number" << endl;
	}
}

void JarType::sub(int n) {
	if (n > 0)
	{
		(n > numUnits) ? numUnits = 0 : numUnits -= n;
	}
	else
	{
		cout << "\nEnter a positive number" << endl;
	}
}

int JarType::quantity() const {
	return numUnits;
}

int JarType::getJarCount()
{
	return jarCount;
}

JarType::JarType() {
	numUnits = 0;
	jarCount++;
	cout << "\nRinsing jar..." << endl;
}

JarType::JarType(int n) {
	numUnits = n;
	jarCount++;
	cout << "\nPrefill jar with " << numUnits << endl;
}

JarType::JarType(char n)
{
	jarCount++;
	switch (n)
	{
	case 'p':
		numUnits = 16;
		break;
	case 'q':
		numUnits = 32;
		break;
	default:
		cerr << "\nInvalid Request" << endl;
		break;
	}
}

JarType::JarType(JarType& j)
{
	cout << "In Copy Constructor" << endl;
	jarCount++;
	numUnits = j.numUnits;
}

JarType::~JarType() {
	cout << "\nDestroying jar" << endl;
	jarCount--;
}