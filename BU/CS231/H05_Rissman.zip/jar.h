#pragma once
// SPECIFICATION FILE
// Declare the abstract data type JarType

// Edit History:
// 09/27/22 JR Created specification file
// 10/06/22 JR Added new JarType constructor with pint and quart options
// 10/22/22 JR Added copy constructor
// 10/22/22 JR Added friend function reveal
// 10/22/22 JR Added static data member to keep track of number of jars

#ifndef JAR_H
#define JAR_H

class JarType {
	friend int  reveal(JarType j);
public:
	JarType();            // Constructor
	JarType(int n);       // Another constructor
	JarType(char n);	  // Pint & Quart constructor
	JarType(JarType& j);  // Copy constructor
	~JarType();           // Destructor
	void initToEmpty();   // Initialize a jar
	void add(int n);      // Add n units to jar
	void sub(int n);      // Subtract n units from jar
	int quantity() const; // Reveal number of units in jar
	static int getJarCount(); //Return number of jars
private:
	int numUnits;
	static int jarCount;
};

#endif // !JAR_H