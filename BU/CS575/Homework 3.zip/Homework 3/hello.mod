/home/jirissman/hello.o
